<div class="card">
  <div class="card-header"><h3 class="card-title">Yeni Menü</h3></div>
  <div class="card-body"><?php include __DIR__ . '/form.php'; ?></div>
</div>
