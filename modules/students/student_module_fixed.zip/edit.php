<?php
$student = $user; // controller’dan gelen veri
include __DIR__ . '/form.php';
