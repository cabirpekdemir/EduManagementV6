<section class="content-header">
  <div class="container-fluid">
    <div class="row mb-2">
      <div class="col-sm-6">
        <h1>Öğrenci Paneline Hoş Geldiniz, <?= htmlspecialchars($user['name']) ?>!</h1>
      </div>
    </div>
  </div>
</section>

<section class="content">
  <div class="container-fluid">
    
    <!-- RANDEVU WİDGET'LARI (Mevcut Sistem) -->
    <?php if (!empty($appointmentData)): ?>
        <div class="row">
            <!-- Bekleyen Talepler -->
            <?php if (!empty($appointmentData['pendingRequests'])): ?>
                <div class="col-md-6">
                    <div class="card card-warning">
                        <div class="card-header">
                            <h3 class="card-title"><i class="fa fa-clock"></i> Bekleyen Taleplerim</h3>
                        </div>
                        <div class="card-body">
                            <ul class="list-group">
                                <?php foreach ($appointmentData['pendingRequests'] as $req): ?>
                                    <li class="list-group-item">
                                        <div class="mb-1">
                                            <span class="badge badge-warning">
                                                <?= date('d.m.Y', strtotime($req['requested_date'])) ?>
                                            </span>
                                            <span class="badge badge-secondary">
                                                <?= date('H:i', strtotime($req['requested_time'])) ?>
                                            </span>
                                        </div>
                                        <small class="text-muted">
                                            Gönderim: <?= date('d.m.Y H:i', strtotime($req['created_at'])) ?>
                                        </small>
                                    </li>
                                <?php endforeach; ?>
                            </ul>
                        </div>
                        <div class="card-footer text-center">
                            <a href="index.php?module=guidance&action=myRequests">Tüm Taleplerim</a>
                        </div>
                    </div>
                </div>
            <?php endif; ?>

            <!-- Onaylanan Randevular -->
            <div class="col-md-6">
                <div class="card card-success">
                    <div class="card-header">
                        <h3 class="card-title"><i class="fa fa-calendar-check"></i> Yaklaşan Randevularım</h3>
                    </div>
                    <div class="card-body">
                        <?php if (empty($appointmentData['upcomingAppointments'])): ?>
                            <div class="text-center text-muted py-4">
                                <i class="fa fa-calendar-alt fa-3x mb-3"></i>
                                <p class="mb-0">Onaylanmış randevunuz bulunmuyor.</p>
                                <a href="index.php?module=guidance&action=requestForm" 
                                   class="btn btn-sm btn-primary mt-2">
                                    <i class="fa fa-plus"></i> Randevu Talebi Oluştur
                                </a>
                            </div>
                        <?php else: ?>
                            <ul class="list-group">
                                <?php foreach ($appointmentData['upcomingAppointments'] as $apt): ?>
                                    <li class="list-group-item">
                                        <div class="mb-1">
                                            <span class="badge badge-success">
                                                <?= date('d.m.Y', strtotime($apt['appointment_date'])) ?>
                                            </span>
                                            <span class="badge badge-primary">
                                                <?= date('H:i', strtotime($apt['appointment_time'])) ?>
                                            </span>
                                        </div>
                                        <?php if (!empty($apt['counselor_name'])): ?>
                                            <small class="text-muted">
                                                <i class="fa fa-user"></i> <?= htmlspecialchars($apt['counselor_name']) ?>
                                            </small>
                                        <?php endif; ?>
                                    </li>
                                <?php endforeach; ?>
                            </ul>
                        <?php endif; ?>
                    </div>
                    <div class="card-footer text-center">
                        <a href="index.php?module=guidance&action=myRequests">Tüm Randevularım</a>
                    </div>
                </div>
            </div>
        </div>

        <!-- Hızlı Erişim -->
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-body text-center">
                        <a href="index.php?module=guidance&action=requestForm" class="btn btn-primary btn-lg mr-2">
                            <i class="fa fa-calendar-plus"></i> Yeni Randevu Talebi
                        </a>
                        <a href="index.php?module=guidance&action=myRequests" class="btn btn-info btn-lg mr-2">
                            <i class="fa fa-list"></i> Taleplerim
                        </a>
                        <a href="index.php?module=guidance&action=index" class="btn btn-success btn-lg">
                            <i class="fa fa-user-friends"></i> Rehberlik Seansları
                        </a>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?>

    <!-- DİNAMİK WIDGET SİSTEMİ -->
    <?php if (isset($widgetLibrary)): ?>
        <div class="row mt-4">
            <div class="col-12">
                <h4 class="mb-3">Dashboard Widget'ları</h4>
            </div>
        </div>
        
        <div id="dynamic-widgets-container">
            <?php echo $widgetLibrary->renderAll(); ?>
        </div>
        
        <!-- Widget Yenileme Butonu -->
        <div class="row mt-3">
            <div class="col-12 text-center">
                <button onclick="refreshAllWidgets()" class="btn btn-sm btn-outline-secondary">
                    <i class="fa fa-sync-alt"></i> Widget'ları Yenile
                </button>
            </div>
        </div>
        
        <script>
        function refreshAllWidgets() {
            const btn = event.target.closest('button');
            const icon = btn.querySelector('i');
            
            btn.disabled = true;
            icon.classList.add('fa-spin');
            
            fetch('index.php?module=dashboard&action=refreshAll', {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    document.getElementById('dynamic-widgets-container').innerHTML = data.html;
                    if (typeof $ !== 'undefined' && $.fn.Toasts) {
                        $(document).Toasts('create', {
                            class: 'bg-success',
                            title: 'Başarılı',
                            body: 'Widget\'lar güncellendi',
                            autohide: true,
                            delay: 3000,
                        });
                    }
                }
            })
            .catch(error => console.error('Error:', error))
            .finally(() => {
                btn.disabled = false;
                icon.classList.remove('fa-spin');
            });
        }
        </script>
    <?php endif; ?>

    <p class="mt-3 text-muted">Burada ders programını, yoklama durumunu ve notlarını görebilirsin.</p>
  </div>
</section>