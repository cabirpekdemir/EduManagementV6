<section class="content-header">
  <div class="container-fluid">
    <div class="row mb-2">
      <div class="col-sm-6">
        <h1>Öğretmen Paneline Hoş Geldiniz, <?= htmlspecialchars($user['name']) ?>!</h1>
      </div>
    </div>
  </div>
</section>

<section class="content">
  <div class="container-fluid">

    <!-- DİNAMİK WIDGET SİSTEMİ -->
    <?php if (isset($widgetLibrary)): ?>
        <div id="dynamic-widgets-container">
            <?php echo $widgetLibrary->renderAll(); ?>
        </div>
        
        <!-- Widget Yenileme Butonu -->
        <div class="row mt-3">
            <div class="col-12 text-center">
                <button onclick="refreshAllWidgets()" class="btn btn-sm btn-outline-secondary">
                    <i class="fa fa-sync-alt"></i> Widget'ları Yenile
                </button>
            </div>
        </div>
        
        <script>
        function refreshAllWidgets() {
            const btn = event.target.closest('button');
            const icon = btn.querySelector('i');
            
            btn.disabled = true;
            icon.classList.add('fa-spin');
            
            fetch('index.php?module=dashboard&action=refreshAll', {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    document.getElementById('dynamic-widgets-container').innerHTML = data.html;
                    if (typeof $ !== 'undefined' && $.fn.Toasts) {
                        $(document).Toasts('create', {
                            class: 'bg-success',
                            title: 'Başarılı',
                            body: 'Widget\'lar güncellendi',
                            autohide: true,
                            delay: 3000,
                        });
                    }
                }
            })
            .catch(error => console.error('Error:', error))
            .finally(() => {
                btn.disabled = false;
                icon.classList.remove('fa-spin');
            });
        }
        </script>
    <?php else: ?>
        <div class="alert alert-info">
            Widget sistemi yüklenmedi. Lütfen sistem yöneticisine başvurun.
        </div>
    <?php endif; ?>

    <p class="mt-3 text-muted">Burada dersleriniz, öğrencileriniz ve sınıf yönetimi araçlarını görebilirsiniz.</p>
  </div>
</section>